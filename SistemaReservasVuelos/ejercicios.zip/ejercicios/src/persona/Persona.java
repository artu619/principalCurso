package persona;

 public class Persona {
	// Atributos
	    String nombre;
	    int edad;
	    double peso;

	    // Constructor
	    public Persona(String nombre, int edad, double peso) {
	        this.nombre = nombre;
	        this.edad = edad;
	        this.peso = peso;
	    }

	    
	 
	 

}
