package Libro;

public class MainLibro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Libro libro = new Libro("El Quijote", "Cervantes", 1605);
        System.out.println(libro);
        System.out.println();
        Libro libro1 = new Libro("el señor de los añillos", "J. R. R. Tolkien", 1954);
        System.out.println(libro1);

	}
	

}
